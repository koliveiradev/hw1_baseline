# hw1

This folder contains baseline code for homework1-manual review.
